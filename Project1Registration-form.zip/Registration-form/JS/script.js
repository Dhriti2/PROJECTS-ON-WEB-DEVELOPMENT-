document.getElementById("registrationForm").addEventListener("submit", function (e) {
  e.preventDefault();

  const username = document.getElementById("username").value.trim();
  const mobile = document.getElementById("MobNo").value.trim();
  const address = document.getElementById("UserAddress").value.trim();
  const department = document.getElementById("department").value;

  const mobileRegex = /^(\+91)?[6-9][0-9]{9}$/;

  if (username.length < 3 || username.length > 26) {
    alert("Invalid username: must be 3–26 characters long.");
    return;
  }

  if (!mobileRegex.test(mobile)) {
    alert("Invalid mobile number: must be a valid Indian number.");
    return;
  }

  if (address.length < 18 || address.length > 100) {
    alert("Invalid address: must be 18–100 characters long.");
    return;
  }

  if (!department) {
    alert("Please select a department.");
    return;
  }

  alert("Form submitted successfully!");
  this.submit();
});
