<?php
// Database connection settings
$host = "localhost"; // Database server, default for XAMPP is localhost
$dbUsername = "root"; // Default username for XAMPP
$dbPassword = ""; // Default password for XAMPP is empty
$dbName = "registration_db"; // The name of your database

// Create connection
$conn = new mysqli($host, $dbUsername, $dbPassword, $dbName);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error); // If connection fails, show the error
}
?>
