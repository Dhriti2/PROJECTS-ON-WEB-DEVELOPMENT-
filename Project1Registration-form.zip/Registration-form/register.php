<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$host = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbName = "registration_db";

$conn = new mysqli($host, $dbUsername, $dbPassword, $dbName);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$username = trim($_POST['name'] ?? '');
$mobile = trim($_POST['mobile'] ?? '');
$address = trim($_POST['address'] ?? '');
$department = trim($_POST['department'] ?? '');

$errors = [];

if (strlen($username) < 3 || strlen($username) > 26) {
    $errors[] = "Username must be between 3 and 26 characters.";
}

if (!preg_match('/^(\+91)?[6-9][0-9]{9}$/', $mobile)) {
    $errors[] = "Invalid Indian mobile number.";
}

if (strlen($address) < 18 || strlen($address) > 100) {
    $errors[] = "Address must be between 18 and 100 characters.";
}

$allowedDepartments = ['CSE', 'ECE', 'EEE', 'ME'];
if (!in_array($department, $allowedDepartments)) {
    $errors[] = "Invalid department selected.";
}

if (!empty($errors)) {
    echo "<h3>Form submission failed due to the following errors:</h3><ul>";
    foreach ($errors as $error) {
        echo "<li>" . htmlspecialchars($error) . "</li>";
    }
    echo "</ul><a href='index.html'>Go Back</a>";
    exit;
}

$sql = "INSERT INTO users (username, mobile, address, department) VALUES (?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
if ($stmt) {
    $stmt->bind_param("ssss", $username, $mobile, $address, $department);
    if ($stmt->execute()) {
        echo "<h2>✅ Registration successful!</h2><a href='index.html'>Register another user</a>";
    } else {
        echo "<h2>❌ Failed to register. Please try again later.</h2>";
    }
    $stmt->close();
} else {
    echo "<h2>❌ Error preparing the statement.</h2>";
}

$conn->close();
?>
